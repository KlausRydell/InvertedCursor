#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "InvertedCursorComponent.generated.h"

class UCameraComponent;
class UMaterialInterface;
class UMaterialInstanceDynamic;
class UTexture2D;


UCLASS(ClassGroup = (Rendering), meta = (BlueprintSpawnableComponent))
class INVERTEDCURSOR_API UInvertedCursorComponent : public UActorComponent
{
	GENERATED_BODY()

public:

	UInvertedCursorComponent();


	// =========================================================================
	// Settings
	// =========================================================================

	/** Post Process material used to invert the scene beneath the cursor mask. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Inverted Cursor")
	TObjectPtr<UMaterialInterface> CursorMaterial = nullptr;

	/** Texture used as the cursor mask. White = inverted, black = unaffected. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Inverted Cursor")
	TObjectPtr<UTexture2D> CursorMask = nullptr;

	/** Cursor dimensions in actual screen pixels. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Inverted Cursor")
	FVector2D CursorSize = FVector2D(16.0, 16.0);

	/**
	 * Cursor position in normalized viewport coordinates.
	 * 0.5, 0.5 = center of the screen.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Inverted Cursor")
	FVector2D CursorPosition = FVector2D(0.5, 0.5);

	/**
	 * Automatically initializes using the first Camera Component
	 * found on the owning actor.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Inverted Cursor")
	bool bAutoInitializeWithOwnerCamera = true;

	/** Whether the cursor starts enabled. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Inverted Cursor")
	bool bStartEnabled = true;


	// =========================================================================
	// Functions
	// =========================================================================

	/**
	 * Initializes the inverted cursor on the supplied Camera Component.
	 * Can also be used to move the effect to another camera.
	 */
	UFUNCTION(BlueprintCallable, Category = "Inverted Cursor")
	bool InitializeCursor(UCameraComponent* InCamera);

	/** Enables or disables the inverted cursor. */
	UFUNCTION(BlueprintCallable, Category = "Inverted Cursor")
	void SetCursorEnabled(bool bEnabled);

	/** Changes the texture used to mask the inverted area. */
	UFUNCTION(BlueprintCallable, Category = "Inverted Cursor")
	void SetCursorMask(UTexture2D* NewMask);

	/** Changes the cursor dimensions in screen pixels. */
	UFUNCTION(BlueprintCallable, Category = "Inverted Cursor")
	void SetCursorSize(FVector2D NewSize);

	/**
	 * Changes the cursor position in normalized viewport coordinates.
	 * 0.5, 0.5 = center.
	 */
	UFUNCTION(BlueprintCallable, Category = "Inverted Cursor")
	void SetCursorPosition(FVector2D NewPosition);

	/** Returns whether the cursor currently has a valid camera and material. */
	UFUNCTION(BlueprintPure, Category = "Inverted Cursor")
	bool IsCursorInitialized() const;

	/** Returns whether the cursor is currently enabled. */
	UFUNCTION(BlueprintPure, Category = "Inverted Cursor")
	bool IsCursorEnabled() const { return bCursorEnabled; }


protected:

	virtual void BeginPlay() override;

	virtual void EndPlay(
		const EEndPlayReason::Type EndPlayReason
	) override;


private:

	/** Camera currently receiving the post-process material. */
	UPROPERTY(Transient)
	TObjectPtr<UCameraComponent> TargetCamera = nullptr;

	/** Runtime instance of CursorMaterial. */
	UPROPERTY(Transient)
	TObjectPtr<UMaterialInstanceDynamic> CursorMID = nullptr;

	bool bCursorEnabled = false;


	// =========================================================================
	// Internal
	// =========================================================================

	/** Pushes the current cursor settings into the dynamic material instance. */
	void UpdateMaterialParameters();
};