#include "InvertedCursorComponent.h"

#include "Camera/CameraComponent.h"
#include "Engine/Texture2D.h"
#include "GameFramework/Actor.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Materials/MaterialInterface.h"


// =============================================================================
// Material Parameter Names
// =============================================================================

namespace InvertedCursorParameters
{
	static const FName Mask(TEXT("CursorMask"));
	static const FName Size(TEXT("CursorSize"));
	static const FName Position(TEXT("CursorPosition"));
}


// =============================================================================
// Constructor
// =============================================================================

UInvertedCursorComponent::UInvertedCursorComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}


// =============================================================================
// Lifecycle
// =============================================================================

void UInvertedCursorComponent::BeginPlay()
{
	Super::BeginPlay();

	bCursorEnabled = bStartEnabled;

	if (!bAutoInitializeWithOwnerCamera)
	{
		return;
	}

	if (IsCursorInitialized())
	{
		return;
	}

	AActor* Owner = GetOwner();

	if (!IsValid(Owner))
	{
		return;
	}

	UCameraComponent* OwnerCamera =
		Owner->FindComponentByClass<UCameraComponent>();

	if (IsValid(OwnerCamera))
	{
		InitializeCursor(OwnerCamera);
	}
}


void UInvertedCursorComponent::EndPlay(
	const EEndPlayReason::Type EndPlayReason
)
{
	// Leave the material attached but give it zero influence.
	if (IsValid(TargetCamera) && IsValid(CursorMID))
	{
		TargetCamera->AddOrUpdateBlendable(
			CursorMID,
			0.0f
		);
	}

	CursorMID = nullptr;
	TargetCamera = nullptr;

	Super::EndPlay(EndPlayReason);
}


// =============================================================================
// Initialization
// =============================================================================

bool UInvertedCursorComponent::InitializeCursor(
	UCameraComponent* InCamera
)
{
	if (!IsValid(InCamera))
	{
		return false;
	}

	if (!IsValid(CursorMaterial))
	{
		return false;
	}


	// -------------------------------------------------------------------------
	// Disable previous instance
	// -------------------------------------------------------------------------

	if (IsValid(TargetCamera) && IsValid(CursorMID))
	{
		TargetCamera->AddOrUpdateBlendable(
			CursorMID,
			0.0f
		);
	}


	// -------------------------------------------------------------------------
	// Create new runtime material
	// -------------------------------------------------------------------------

	TargetCamera = InCamera;

	CursorMID = UMaterialInstanceDynamic::Create(
		CursorMaterial,
		this
	);

	if (!IsValid(CursorMID))
	{
		TargetCamera = nullptr;
		return false;
	}


	// -------------------------------------------------------------------------
	// Configure
	// -------------------------------------------------------------------------

	UpdateMaterialParameters();

	TargetCamera->AddOrUpdateBlendable(
		CursorMID,
		bCursorEnabled ? 1.0f : 0.0f
	);

	return true;
}


// =============================================================================
// Cursor Control
// =============================================================================

void UInvertedCursorComponent::SetCursorEnabled(
	bool bEnabled
)
{
	bCursorEnabled = bEnabled;

	if (!IsCursorInitialized())
	{
		return;
	}

	TargetCamera->AddOrUpdateBlendable(
		CursorMID,
		bCursorEnabled ? 1.0f : 0.0f
	);
}


void UInvertedCursorComponent::SetCursorMask(
	UTexture2D* NewMask
)
{
	CursorMask = NewMask;

	if (!IsValid(CursorMID))
	{
		return;
	}

	if (!IsValid(CursorMask))
	{
		return;
	}

	CursorMID->SetTextureParameterValue(
		InvertedCursorParameters::Mask,
		CursorMask
	);
}


void UInvertedCursorComponent::SetCursorSize(
	FVector2D NewSize
)
{
	CursorSize.X = FMath::Max(NewSize.X, 1.0);
	CursorSize.Y = FMath::Max(NewSize.Y, 1.0);

	if (!IsValid(CursorMID))
	{
		return;
	}

	CursorMID->SetVectorParameterValue(
		InvertedCursorParameters::Size,
		FLinearColor(
			static_cast<float>(CursorSize.X),
			static_cast<float>(CursorSize.Y),
			0.0f,
			0.0f
		)
	);
}


void UInvertedCursorComponent::SetCursorPosition(
	FVector2D NewPosition
)
{
	CursorPosition.X = FMath::Clamp(
		NewPosition.X,
		0.0,
		1.0
	);

	CursorPosition.Y = FMath::Clamp(
		NewPosition.Y,
		0.0,
		1.0
	);

	if (!IsValid(CursorMID))
	{
		return;
	}

	CursorMID->SetVectorParameterValue(
		InvertedCursorParameters::Position,
		FLinearColor(
			static_cast<float>(CursorPosition.X),
			static_cast<float>(CursorPosition.Y),
			0.0f,
			0.0f
		)
	);
}


bool UInvertedCursorComponent::IsCursorInitialized() const
{
	return IsValid(TargetCamera) && IsValid(CursorMID);
}


// =============================================================================
// Material Parameters
// =============================================================================

void UInvertedCursorComponent::UpdateMaterialParameters()
{
	if (!IsValid(CursorMID))
	{
		return;
	}


	// -------------------------------------------------------------------------
	// Mask
	// -------------------------------------------------------------------------

	if (IsValid(CursorMask))
	{
		CursorMID->SetTextureParameterValue(
			InvertedCursorParameters::Mask,
			CursorMask
		);
	}


	// -------------------------------------------------------------------------
	// Size
	// -------------------------------------------------------------------------

	CursorMID->SetVectorParameterValue(
		InvertedCursorParameters::Size,
		FLinearColor(
			static_cast<float>(CursorSize.X),
			static_cast<float>(CursorSize.Y),
			0.0f,
			0.0f
		)
	);


	// -------------------------------------------------------------------------
	// Position
	// -------------------------------------------------------------------------

	CursorMID->SetVectorParameterValue(
		InvertedCursorParameters::Position,
		FLinearColor(
			static_cast<float>(CursorPosition.X),
			static_cast<float>(CursorPosition.Y),
			0.0f,
			0.0f
		)
	);
}